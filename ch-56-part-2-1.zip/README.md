# toone
my 107 website

## about
this repository has all the code for my 107 **website**
> Data is a precious thing and will last longer than the systems themselves.
> Tim Berners-Lee

### updates
10/24/2022 - added javascript to the project
