<?php
  @unlink("guestbook.csv");